function Response(resp) {
    this.left = resp.left.sort(compare)
    this.middle = resp.middle.sort(compare)
    this.right = resp.right.sort(compare)
    this.bottom = resp.bottom.sort(compare)
}

function compare(a,b){
    return b.value-a.value
}

module.exports = Response;
