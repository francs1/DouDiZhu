function usermsg() {
    this.id = ''
    this.username = ''
    this.cardlist = []
    this.activity = false
    this.precardlist = []
    this.landload = false
}

module.exports = usermsg
