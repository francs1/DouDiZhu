var Cards = require('./cards.js')

function Rules() {
    this.left = new Array()
    this.middle = new Array()
    this.right = new Array()
    this.bottom = new Array()
}
module.exports = Rules;

function randomsort(a,b) {
    return Math.random()>.5?-1:1
}

function testsort(a,b) {
    return a.value < b.value

}

function randomCards(cardlist){
    var n = cardlist.length;
    console.log('n='+n)
    var c = Math.floor(Math.random()*n)
    while(c != 53){
        console.log(c)
        c = Math.floor(Math.random()*n)
    }
    console.log('finish,c='+c)
}

Rules.init = function () {
    //randomCards(Cards.cardlist)
    let randomlist = Cards.cardlist.sort(randomsort)
    this.left = randomlist.slice(0,17)
    this.middle = randomlist.slice(17,34)
    this.right = randomlist.slice(34,51)
    this. bottom = randomlist.slice(51,54)
    //console.log(left,middle,right,bottom)
}

Rules.test = function () {
    let randomlist = Cards.testlist
    this.left = randomlist.slice(0,17)
    this.middle = randomlist.slice(17,34)
    this.right = randomlist.slice(34,51)
    this. bottom = randomlist.slice(51,54)
}
