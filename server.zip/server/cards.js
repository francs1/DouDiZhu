function Cards() {

}

module.exports=Cards

Cards.cardlist = [
    {
        id:1,
        name:'3',
        type:'hearts',
        value:3,
        img:'3hongt_Size_Format.png'
    },
    {
        id:2,
        name:'4',
        type:'hearts',
        value:4,
        img:'4hongt_Size_Format.png'
    },
    {
        id:3,
        name:'5',
        type:'hearts',
        value:5,
        img:'5hongt_Size_Format.png'
    },
    {
        id:4,
        name:'6',
        type:'hearts',
        value:6,
        img:'6hongt_Size_Format.png'
    },
    {
        id:5,
        name:'7',
        type:'hearts',
        value:7,
        img:'7hongt_Size_Format.png'
    },
    {
        id:6,
        name:'8',
        type:'hearts',
        value:8,
        img:'8hongt_Size_Format.png'
    },
    {
        id:7,
        name:'9',
        type:'hearts',
        value:9,
        img:'9hongt_Size_Format.png'
    },
    {
        id:8,
        name:'10',
        type:'hearts',
        value:10,
        img:'10hongt_Size_Format.png'
    },
    {
        id:9,
        name:'J',
        type:'hearts',
        value:11,
        img:'Jhongt_Size_Format.png'
    },
    {
        id:10,
        name:'Q',
        type:'hearts',
        value:12,
        img:'Qhongt_Size_Format.png'
    },
    {
        id:11,
        name:'K',
        type:'hearts',
        value:13,
        img:'Khongt_Size_Format.png'
    },
    {
        id:12,
        name:'A',
        type:'hearts',
        value:14,
        img:'Acehongt_Size_Format.png'
    },
    {
        id:13,
        name:'2',
        type:'hearts',
        value:16,
        img:'2hongt_Size_Format.png'
    },
    {
        id:14,
        name:'3',
        type:'spades',
        value:3,
        img:'3heit_Size_Format.png'
    },
    {
        id:15,
        name:'4',
        type:'spades',
        value:4,
        img:'4heit_Size_Format.png'
    },
    {
        id:16,
        name:'5',
        type:'spades',
        value:5,
        img:'5heit_Size_Format.png'
    },
    {
        id:17,
        name:'6',
        type:'spades',
        value:6,
        img:'6heit_Size_Format.png'
    },
    {
        id:18,
        name:'7',
        type:'spades',
        value:7,
        img:'7heit_Size_Format.png'
    },
    {
        id:19,
        name:'8',
        type:'spades',
        value:8,
        img:'8heit_Size_Format.png'
    },
    {
        id:20,
        name:'9',
        type:'spades',
        value:9,
        img:'9heit_Size_Format.png'
    },
    {
        id:21,
        name:'10',
        type:'spades',
        value:10,
        img:'10heit_Size_Format.png'
    },
    {
        id:22,
        name:'J',
        type:'spades',
        value:11,
        img:'Jheit_Size_Format.png'
    },
    {
        id:23,
        name:'Q',
        type:'spades',
        value:12,
        img:'Qheit_Size_Format.png'
    },
    {
        id:24,
        name:'K',
        type:'spades',
        value:13,
        img:'Kheit_Size_Format.png'
    },
    {
        id:25,
        name:'A',
        type:'spades',
        value:14,
        img:'Aceheit_Size_Format.png'
    },
    {
        id:26,
        name:'2',
        type:'spades',
        value:16,
        img:'2heit_Size_Format.png'
    },
    {
        id:27,
        name:'3',
        type:'diamonds',
        value:3,
        img:'3fangk_Size_Format.png'
    },
    {
        id:28,
        name:'4',
        type:'diamonds',
        value:4,
        img:'4fangk_Size_Format.png'
    },
    {
        id:29,
        name:'5',
        type:'diamonds',
        value:5,
        img:'5fangk_Size_Format.png'
    },
    {
        id:30,
        name:'6',
        type:'diamonds',
        value:6,
        img:'6fangk_Size_Format.png'
    },
    {
        id:31,
        name:'7',
        type:'diamonds',
        value:7,
        img:'7fangk_Size_Format.png'
    },
    {
        id:32,
        name:'8',
        type:'diamonds',
        value:8,
        img:'8fangk_Size_Format.png'
    },
    {
        id:33,
        name:'9',
        type:'diamonds',
        value:9,
        img:'9fangk_Size_Format.png'
    },
    {
        id:34,
        name:'10',
        type:'diamonds',
        value:10,
        img:'10fangk_Size_Format.png'
    },
    {
        id:35,
        name:'J',
        type:'diamonds',
        value:11,
        img:'Jfangk_Size_Format.png'
    },
    {
        id:36,
        name:'Q',
        type:'diamonds',
        value:12,
        img:'Qfangk_Size_Format.png'
    },
    {
        id:37,
        name:'K',
        type:'diamonds',
        value:13,
        img:'Kfangk_Size_Format.png'
    },
    {
        id:38,
        name:'A',
        type:'diamonds',
        value:14,
        img:'Acefangk_Size_Format.png'
    },
    {
        id:39,
        name:'2',
        type:'diamonds',
        value:16,
        img:'2fangk_Size_Format.png'
    },
    {
        id:40,
        name:'3',
        type:'clubs',
        value:3,
        img:'3meih_Size_Format.png'
    },
    {
        id:41,
        name:'4',
        type:'clubs',
        value:4,
        img:'4meih_Size_Format.png'
    },
    {
        id:42,
        name:'5',
        type:'clubs',
        value:5,
        img:'5meih_Size_Format.png'
    },
    {
        id:43,
        name:'6',
        type:'clubs',
        value:6,
        img:'6meih_Size_Format.png'
    },
    {
        id:44,
        name:'7',
        type:'clubs',
        value:7,
        img:'7meih_Size_Format.png'
    },
    {
        id:45,
        name:'8',
        type:'clubs',
        value:8,
        img:'8meih_Size_Format.png'
    },
    {
        id:46,
        name:'9',
        type:'clubs',
        value:9,
        img:'9meih_Size_Format.png'
    },
    {
        id:47,
        name:'10',
        type:'clubs',
        value:10,
        img:'10meih_Size_Format.png'
    },
    {
        id:48,
        name:'J',
        type:'clubs',
        value:11,
        img:'Jmeih_Size_Format.png'
    },
    {
        id:49,
        name:'Q',
        type:'clubs',
        value:12,
        img:'Qmeih_Size_Format.png'
    },
    {
        id:50,
        name:'K',
        type:'clubs',
        value:13,
        img:'Kmeih_Size_Format.png'
    },
    {
        id:51,
        name:'A',
        type:'clubs',
        value:14,
        img:'Acemeih_Size_Format.png'
    },
    {
        id:52,
        name:'2',
        type:'clubs',
        value:16,
        img:'2meih_Size_Format.png'
    },
    {
        id:53,
        name:'s',
        type:'-',
        value:18,
        img:'Xw_Size_Format.png'
    },
    {
        id:54,
        name:'S',
        type:'-',
        value:19,
        img:'Dw_Size_Format.png'
    }
]


Cards.testlist = [
    {
        id:1,
        name:'3',
        type:'hearts',
        value:3
    },
    {
        id:14,
        name:'3',
        type:'spades',
        value:3
    },
    {
        id:27,
        name:'3',
        type:'diamonds',
        value:3
    },
    {
        id:40,
        name:'3',
        type:'clubs',
        value:3
    },
    {
        id:2,
        name:'4',
        type:'hearts',
        value:4
    },
    {
        id:15,
        name:'4',
        type:'spades',
        value:4
    },
    {
        id:28,
        name:'4',
        type:'diamonds',
        value:4
    },
    {
        id:41,
        name:'4',
        type:'clubs',
        value:4
    },
    {
        id:3,
        name:'5',
        type:'hearts',
        value:5
    },
    {
        id:16,
        name:'5',
        type:'spades',
        value:5
    },
    {
        id:29,
        name:'5',
        type:'diamonds',
        value:5
    },
    {
        id:42,
        name:'5',
        type:'clubs',
        value:5
    },
    {
        id:4,
        name:'6',
        type:'hearts',
        value:6
    },
    {
        id:17,
        name:'6',
        type:'spades',
        value:6
    },
    {
        id:30,
        name:'6',
        type:'diamonds',
        value:6
    },
    {
        id:43,
        name:'6',
        type:'clubs',
        value:6
    },
    {
        id:5,
        name:'7',
        type:'hearts',
        value:7
    },
    {
        id:18,
        name:'7',
        type:'spades',
        value:7
    },
    {
        id:31,
        name:'7',
        type:'diamonds',
        value:7
    },
    {
        id:44,
        name:'7',
        type:'clubs',
        value:7
    },
    {
        id:6,
        name:'8',
        type:'hearts',
        value:8
    },
    {
        id:19,
        name:'8',
        type:'spades',
        value:8
    },
    {
        id:32,
        name:'8',
        type:'diamonds',
        value:8
    },
    {
        id:45,
        name:'8',
        type:'clubs',
        value:8
    },
    {
        id:7,
        name:'9',
        type:'hearts',
        value:9
    },
    {
        id:20,
        name:'9',
        type:'spades',
        value:9
    },
    {
        id:33,
        name:'9',
        type:'diamonds',
        value:9
    },
    {
        id:46,
        name:'9',
        type:'clubs',
        value:9
    },
    {
        id:8,
        name:'10',
        type:'hearts',
        value:10
    },
    {
        id:21,
        name:'10',
        type:'spades',
        value:10
    },
    {
        id:34,
        name:'10',
        type:'diamonds',
        value:10
    },
    {
        id:47,
        name:'10',
        type:'clubs',
        value:10
    },
    {
        id:9,
        name:'J',
        type:'hearts',
        value:11
    },
    {
        id:22,
        name:'J',
        type:'spades',
        value:11
    },
    {
        id:35,
        name:'J',
        type:'diamonds',
        value:11
    },
    {
        id:48,
        name:'J',
        type:'clubs',
        value:11
    },
    {
        id:10,
        name:'Q',
        type:'hearts',
        value:12
    },
    {
        id:23,
        name:'Q',
        type:'spades',
        value:12
    },
    {
        id:36,
        name:'Q',
        type:'diamonds',
        value:12
    },
    {
        id:49,
        name:'Q',
        type:'clubs',
        value:12
    },
    {
        id:11,
        name:'K',
        type:'hearts',
        value:13
    },
    {
        id:24,
        name:'K',
        type:'spades',
        value:13
    },
    {
        id:37,
        name:'K',
        type:'diamonds',
        value:13
    },
    {
        id:50,
        name:'K',
        type:'clubs',
        value:13
    },
    {
        id:12,
        name:'A',
        type:'hearts',
        value:14
    },
    {
        id:25,
        name:'A',
        type:'spades',
        value:14
    },
    {
        id:38,
        name:'A',
        type:'diamonds',
        value:14
    },
    {
        id:51,
        name:'A',
        type:'clubs',
        value:14
    },
    {
        id:13,
        name:'2',
        type:'hearts',
        value:16
    },
    {
        id:26,
        name:'2',
        type:'spades',
        value:16
    },
    {
        id:39,
        name:'2',
        type:'diamonds',
        value:16
    },
    {
        id:52,
        name:'2',
        type:'clubs',
        value:16
    },
    {
        id:53,
        name:'s',
        type:'-',
        value:18
    },
    {
        id:54,
        name:'S',
        type:'-',
        value:19
    }
]

// Cards.cardlist = [
//     {
//         id:'01',
//         name:'3',
//         type:'hearts',
//         value:'03'
//     },
//     {
//         id:'02',
//         name:'4',
//         type:'hearts',
//         value:'04'
//     },
//     {
//         id:'03',
//         name:'5',
//         type:'hearts',
//         value:'05'
//     },
//     {
//         id:'04',
//         name:'6',
//         type:'hearts',
//         value:'06'
//     },
//     {
//         id:'05',
//         name:'7',
//         type:'hearts',
//         value:'07'
//     },
//     {
//         id:'06',
//         name:'8',
//         type:'hearts',
//         value:'08'
//     },
//     {
//         id:'07',
//         name:'9',
//         type:'hearts',
//         value:'09'
//     },
//     {
//         id:'08',
//         name:'10',
//         type:'hearts',
//         value:'10'
//     },
//     {
//         id:'09',
//         name:'J',
//         type:'hearts',
//         value:'11'
//     },
//     {
//         id:'10',
//         name:'Q',
//         type:'hearts',
//         value:'12'
//     },
//     {
//         id:'11',
//         name:'K',
//         type:'hearts',
//         value:'13'
//     },
//     {
//         id:'12',
//         name:'A',
//         type:'hearts',
//         value:'14'
//     },
//     {
//         id:'13',
//         name:'2',
//         type:'hearts',
//         value:'16'
//     },
//     {
//         id:'14',
//         name:'3',
//         type:'spades',
//         value:'03'
//     },
//     {
//         id:'15',
//         name:'4',
//         type:'spades',
//         value:'04'
//     },
//     {
//         id:'16',
//         name:'5',
//         type:'spades',
//         value:'05'
//     },
//     {
//         id:'17',
//         name:'6',
//         type:'spades',
//         value:'06'
//     },
//     {
//         id:'18',
//         name:'7',
//         type:'spades',
//         value:'07'
//     },
//     {
//         id:'19',
//         name:'8',
//         type:'spades',
//         value:'08'
//     },
//     {
//         id:'20',
//         name:'9',
//         type:'spades',
//         value:'09'
//     },
//     {
//         id:'21',
//         name:'10',
//         type:'spades',
//         value:'10'
//     },
//     {
//         id:'22',
//         name:'J',
//         type:'spades',
//         value:'11'
//     },
//     {
//         id:'23',
//         name:'Q',
//         type:'spades',
//         value:'12'
//     },
//     {
//         id:'24',
//         name:'K',
//         type:'spades',
//         value:'13'
//     },
//     {
//         id:'25',
//         name:'A',
//         type:'spades',
//         value:'14'
//     },
//     {
//         id:'26',
//         name:'2',
//         type:'spades',
//         value:'16'
//     },
//     {
//         id:'27',
//         name:'3',
//         type:'diamonds',
//         value:'03'
//     },
//     {
//         id:'28',
//         name:'4',
//         type:'diamonds',
//         value:'04'
//     },
//     {
//         id:'29',
//         name:'5',
//         type:'diamonds',
//         value:'05'
//     },
//     {
//         id:'30',
//         name:'6',
//         type:'diamonds',
//         value:'06'
//     },
//     {
//         id:'31',
//         name:'7',
//         type:'diamonds',
//         value:'07'
//     },
//     {
//         id:'32',
//         name:'8',
//         type:'diamonds',
//         value:'08'
//     },
//     {
//         id:'33',
//         name:'9',
//         type:'diamonds',
//         value:'09'
//     },
//     {
//         id:'34',
//         name:'10',
//         type:'diamonds',
//         value:'10'
//     },
//     {
//         id:'35',
//         name:'J',
//         type:'diamonds',
//         value:'11'
//     },
//     {
//         id:'36',
//         name:'Q',
//         type:'diamonds',
//         value:'12'
//     },
//     {
//         id:'37',
//         name:'K',
//         type:'diamonds',
//         value:'13'
//     },
//     {
//         id:'38',
//         name:'A',
//         type:'diamonds',
//         value:'14'
//     },
//     {
//         id:'39',
//         name:'2',
//         type:'diamonds',
//         value:'16'
//     },
//     {
//         id:'40',
//         name:'3',
//         type:'clubs',
//         value:'03'
//     },
//     {
//         id:'41',
//         name:'4',
//         type:'clubs',
//         value:'04'
//     },
//     {
//         id:'42',
//         name:'5',
//         type:'clubs',
//         value:'05'
//     },
//     {
//         id:'43',
//         name:'6',
//         type:'clubs',
//         value:'06'
//     },
//     {
//         id:'44',
//         name:'7',
//         type:'clubs',
//         value:'07'
//     },
//     {
//         id:'45',
//         name:'8',
//         type:'clubs',
//         value:'08'
//     },
//     {
//         id:'46',
//         name:'9',
//         type:'clubs',
//         value:'09'
//     },
//     {
//         id:'47',
//         name:'10',
//         type:'clubs',
//         value:'10'
//     },
//     {
//         id:'48',
//         name:'J',
//         type:'clubs',
//         value:'11'
//     },
//     {
//         id:'49',
//         name:'Q',
//         type:'clubs',
//         value:'12'
//     },
//     {
//         id:'50',
//         name:'K',
//         type:'clubs',
//         value:'13'
//     },
//     {
//         id:'51',
//         name:'A',
//         type:'clubs',
//         value:'14'
//     },
//     {
//         id:'52',
//         name:'2',
//         type:'clubs',
//         value:'16'
//     },
//     {
//         id:'53',
//         name:'s',
//         type:'-',
//         value:'18'
//     },
//     {
//         id:'54',
//         name:'S',
//         type:'-',
//         value:'19'
//     }
// ]
