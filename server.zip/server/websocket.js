var ws = require("nodejs-websocket")
console.log('websocket开始连接')
var Cards = require('./cards.js')
var ru = require("./rules.js")
var response = require("./response.js")
var userlist = new Array()
var usermsg = require("./usermsg.js")
var rooms = new Array()

function sendMsg(server,conn,s,resp){
    var players = rooms[s.roomid]
    server.connections.forEach(function (conn) {
        players.forEach(function (p) {
            if(conn.headers['sec-websocket-key'] == p.id){
                var result = JSON.stringify(resp)
                conn.sendText(result)
            }
        })
    })
}

function cmp(a,b) {
    return b.value - a.value
}

let server = ws.createServer(function (conn) {

    conn.on("text",function (str) {
        let s = JSON.parse(str)
        console.log("收到的信息:"+str)
        if(s.option == 'conn'){
            let user = new usermsg()
            let key = conn.headers['sec-websocket-key']
            user.id = key
            user.username = s.username
            user.activity = false
            user.landload = false
            if(userlist.indexOf(user) == -1){
                userlist.push(user)
            }
            if(!rooms.hasOwnProperty(s.id)){
                rooms[s.roomid] = userlist
            }
            else{
                rooms[s.roomid].push(user)
            }
            let resp = {
                resulttype:0,
                clientid:key
            }
            console.log(rooms[s.roomid].length)
            if(rooms[s.roomid].length == 3){
                ru.init()
                resp.resulttype = 1
                let activity = Math.floor(Math.random()*3)
                rooms[s.roomid][0].cardlist = ru.left.sort(cmp)
                rooms[s.roomid][1].cardlist = ru.middle.sort(cmp)
                rooms[s.roomid][2].cardlist = ru.right.sort(cmp)
                rooms[s.roomid][activity].activity = true
                rooms[s.roomid][activity].landload = true
                rooms[s.roomid][activity].cardlist = rooms[s.roomid][activity].cardlist.concat(ru.bottom)
                rooms[s.roomid][activity].cardlist.sort(cmp)
                resp.cardlist = rooms[s.roomid]
                resp.bottom = ru.bottom.sort()
                resp.clientid=key
            }
            else if(rooms[s.roomid].length > 3){
                resp = {
                    resulttype:2//结束
                }
                sendMsg(server,conn,s,resp)
                return
            }

            sendMsg(server,conn,s,resp)
        }
        else if(s.option == 'play'){
            let key = conn.headers['sec-websocket-key']
            let resp = {
                resulttype:1,
                clientid:key,
                precards:s.sendcards,//复制数组
                preclientid:key
            }

            for(let i=0;i<rooms[s.roomid].length;i++){
                let p = rooms[s.roomid][i]
                if(p.activity){
                    p.precardlist = []

                    for(let x=0;x<s.sendcards.length;x++){
                        for(let y=0;y<Cards.cardlist.length;y++){
                            if(s.sendcards[x][0] == Cards.cardlist[y].id){
                                p.precardlist.push(Cards.cardlist[y])
                            }
                        }
                    }
                    p.activity = false
                    //出牌的人手牌减少
                    if(s.sendcards.length < p.cardlist.length){
                        for(let j=0;j<s.sendcards.length;j++){
                            let card_id = s.sendcards[j][0]
                            for(let k=0;k<p.cardlist.length;k++){
                                let own_card_id = p.cardlist[k].id
                                if(card_id == own_card_id){
                                    p.cardlist.splice(k,1)
                                    break
                                }
                            }
                        }
                    }
                    else{
                        //已经出完全部的牌了，获得胜利
                        resp = {
                            resulttype:2,//结束
                            landloadwin:p.landload
                        }
                        sendMsg(server,conn,s,resp)
                        rooms[s.roomid] = []
                        rooms = null
                        return
                    }

                    let nextid = (i+1) % 3
                    rooms[s.roomid][nextid].activity = true
                    break
                }
            }

            resp.cardlist=rooms[s.roomid]
            sendMsg(server,conn,s,resp)
        }
        else if(s.option == 'no'){
            let key = conn.headers['sec-websocket-key']
            let resp = {
                resulttype:1,
                clientid:key,
                precards:s.precards,//复制数组
                preclientid:s.preclientid
            }
            for(let i=0;i<rooms[s.roomid].length;i++){
                let p = rooms[s.roomid][i]
                if(p.activity){
                    p.precardlist = []
                    p.activity = false

                    let nextid = (i+1) % 3
                    console.log('nextid:'+nextid)
                    rooms[s.roomid][nextid].activity = true
                    break
                }
            }
            // rooms[s.roomid].forEach(function (r) {
            //     console.log(r)
            // })
            resp.cardlist=rooms[s.roomid]
            sendMsg(server,conn,s,resp)
        }

    })
    conn.on("close",function (code,reason) {
        console.log("关闭连接")
        rooms = null
    })
    conn.on("error",function (code,reason) {
        console.log("出错"+reason)
    })
}).listen(8001)
console.log("websocket已经建立")

