var ws = require("nodejs-websocket")
var Cards = require('./cards.js')
var ru = require("./rules.js")
var response = require("./response.js")
var usermsg = require("./usermsg.js")
var rooms = new Array()

function sendMsg(server,roomid,resp){
    let players = rooms[roomid]
    let conns = []
    server.connections.forEach(c=>{
        players.forEach(p=>{
            if(c.key == p.id){
                conns.push(c)
            }
        })
    })
    conns.forEach(c=>{
        let result = JSON.stringify(resp)
        c.sendText(result)
    })
}

function closeConn(server,roomid){
    let players = rooms[roomid]
    let conns = []
    server.connections.forEach(c=>{
        players.forEach(p=>{
            console.log('c.key='+c.key +'|p.id='+p.id)
            if(c.key == p.id){
                conns.push(c)
                console.log('equal:'+c.key)
            }
        })
    })
    console.log(conns.length)
    conns.forEach(c=>{
        c.close(1000)
    })
}

function cmp(a,b) {
    return b.value - a.value
}

let server = ws.createServer(function (conn) {
    conn.on("text",function (str) {
        let s = JSON.parse(str)
        console.log("收到的信息:"+str)
        if(s.option == 'conn'){
            let user = new usermsg()
            let key = conn.headers['sec-websocket-key']
            user.id = key
            user.username = s.username
            user.activity = false
            user.landload = false

            if(!rooms.hasOwnProperty(s.roomid)){
                rooms[s.roomid] = new Array()
                rooms[s.roomid].push(user)
            }
            else{
                rooms[s.roomid].push(user)
            }
            let resp = {
                resulttype:0,
                clientid:key
            }
            if(rooms[s.roomid].length < 3){
                let re = JSON.stringify(resp)
                conn.sendText(re)
            }
            else if(rooms[s.roomid].length == 3){
                ru.init()
                resp.resulttype = 1
                let activity = Math.floor(Math.random()*3)
                rooms[s.roomid][0].cardlist = ru.left.sort(cmp)
                rooms[s.roomid][1].cardlist = ru.middle.sort(cmp)
                rooms[s.roomid][2].cardlist = ru.right.sort(cmp)
                rooms[s.roomid][activity].activity = true
                rooms[s.roomid][activity].landload = true
                rooms[s.roomid][activity].cardlist = rooms[s.roomid][activity].cardlist.concat(ru.bottom)
                rooms[s.roomid][activity].cardlist.sort(cmp)
                resp.cardlist = rooms[s.roomid]
                resp.bottom = ru.bottom.sort()
                resp.clientid=key
                sendMsg(server,s.roomid,resp)
            }
            else if(rooms[s.roomid].length > 3){
                resp = {
                    resulttype:2,//结束
                }

                sendMsg(server,s.roomid,resp)

                if(rooms && s && s.roomid != undefined){
                    rooms[s.roomid].length = 0
                }
                return
            }
            console.log('rooms.len:'+rooms[s.roomid].length)
        }
        else if(s.option == 'play'){
            let key = conn.headers['sec-websocket-key']
            let resp = {
                resulttype:1,
                clientid:key,
                precards:[],//复制数组
                preclientid:key,
                gameover:false,
                roomid:s.roomid,
                cardtype:s.cardtype,
                cardval:s.cardval,
            }
            for(let x=0;x<s.sendcards.length;x++){
                for(let y=0;y<Cards.cardlist.length;y++){
                    if(s.sendcards[x][0] == Cards.cardlist[y].id){
                        resp.precards.push(Cards.cardlist[y])
                    }
                }
            }

            for(let i=0;i<rooms[s.roomid].length;i++){
                let p = rooms[s.roomid][i]
                if(p.activity){
                    p.precardlist = []

                    for(let x=0;x<s.sendcards.length;x++){
                        for(let y=0;y<Cards.cardlist.length;y++){
                            if(s.sendcards[x][0] == Cards.cardlist[y].id){
                                p.precardlist.push(Cards.cardlist[y])
                            }
                        }
                    }
                    p.activity = false
                    //出牌的人手牌减少
                    if(s.sendcards.length < p.cardlist.length){
                        for(let j=0;j<s.sendcards.length;j++){
                            let card_id = s.sendcards[j][0]
                            for(let k=0;k<p.cardlist.length;k++){
                                let own_card_id = p.cardlist[k].id
                                if(card_id == own_card_id){
                                    p.cardlist.splice(k,1)
                                    break
                                }
                            }
                        }
                    }
                    else{
                        resp.landloadwin = p.landload
                        resp.gameover = true
                    }

                    let nextid = (i+1) % 3
                    rooms[s.roomid][nextid].activity = true
                    break
                }
            }

            resp.cardlist=rooms[s.roomid]
            sendMsg(server,s.roomid,resp)
        }
        else if(s.option == 'no'){
            let key = conn.headers['sec-websocket-key']
            let resp = {
                resulttype:1,
                clientid:key,
                precards:[],//复制数组
                preclientid:s.preclientid,
                cardtype:0,
                cardval: Math.floor(Math.random()*4),//0,1,2,3
            }
            for(let x=0;x<s.precards.length;x++){
                for(let y=0;y<Cards.cardlist.length;y++){
                    if(s.precards[x].id == Cards.cardlist[y].id){
                        resp.precards.push(Cards.cardlist[y])
                    }
                }
            }
            for(let i=0;i<rooms[s.roomid].length;i++){
                let p = rooms[s.roomid][i]
                if(p.activity){
                    p.precardlist = []
                    p.activity = false
                    let nextid = (i+1) % 3
                    rooms[s.roomid][nextid].activity = true
                    break
                }
            }

            resp.cardlist=rooms[s.roomid]
            sendMsg(server,s.roomid,resp)
        }
        else if(s.option == 'close'){
            if(rooms && s && s.roomid != undefined && rooms[s.roomid].length >= 3){
                closeConn(server,s.roomid)
                rooms[s.roomid].length = 0
            }
        }
    })
    conn.on("close",function (code,reason) {
        if(reason){
            let res = JSON.parse(reason)
            if(rooms && res && res.roomid != undefined && rooms[res.roomid].length >=3){
                rooms[res.roomid].length = 0
            }
        }
        console.log('server.connections.length:'+server.connections.length)
        console.log("关闭连接")
    })
    conn.on("error",function (code,reason) {
        console.log("出错,code:"+code+',reason:'+reason)
    })
}).listen(8001)
console.log("websocket已经建立")

