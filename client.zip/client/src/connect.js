export default {
    name:'connection',
}
