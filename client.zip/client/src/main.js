import Vue from 'vue'
import Vuex from 'vuex'
import router from 'vue-router'
import App from './App.vue'

Vue.use(Vuex)
Vue.use(router)
Vue.config.productionTip = false

var store = new Vuex.Store({
    state:{
        resp:[],
        count:0
    },
    mutations:{}
})

new Vue({
  render: h => h(App),
    store
}).$mount('#app')
