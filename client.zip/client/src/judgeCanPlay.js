export default {
    name:'judgeCanPlay',
    judge(sendCards,preCards){
        if(preCards.length == 0){
            return true
        }
        else{
            let preResult = this.getType(preCards)
            console.log('preResult:'+preResult)
            let sendResult = this.getType(sendCards)
            console.log('sendCards:'+sendCards)
            if(sendResult.type == 5 && sendResult.val == 19){//王炸秒杀一切
                return true
            }
            if(preResult.type == 5 && preResult.val == 19){//没有人可以阻挡王炸
                return false
            }
            if(preResult.type!=0 && sendResult.type!=0 && preResult.type == sendResult.type && preCards.length == sendCards.length && preResult.val < sendResult.val){
                return true
            }
            else if(preResult.type!=0 && sendResult.type!=0 && preResult.type != 5 && sendResult.type== 5){
                return true
            }
            else{
                return false
            }
        }

    },
    getType(arry){
        let result = getCardsType(arry)
        console.log(result)
        return result
    }
}
//牌的类型：
// 0.不符合出牌规则
// 1.单张
// 2.对子
// 3.三张
// 4.三带一(一组三张，附带任意一张单牌)
// 5.炸弹
// 6.四带两单(一组四张，附带任意两张单牌)
// 7.四带两对(一组四张，附带任意两个对子)
// 8.顺子(连续单张大于等于5张)
// 9.连对(连续对子大于等于3对)
// 10.飞机(连续三张大于等于x组，并且可附带任意y张单牌或y个对子，附带的单牌或对子不需要连续,x大于等于2，y小于等于x)
function getCardsType(arry) {
    console.log(arry)
    var result = {type:0,val:0}
    var n = arry.length

    if(n == 1){//单牌
        result.type=1
        result.val=arry[0]
    }
    else if(n == 2){
        if(arry[0] == arry[1]){//对子
            result.type = 2
            result.val = arry[0]
        }
        else if((arry[0] == 18 && arry[1] == 19) || (arry[0] == 19 && arry[1] == 18)){
            //王炸
            result.type = 5
            result.val = 19
        }
    }
    else if(n == 3){
        if(arry[0] == arry[1] && arry[1] == arry[2]){//三张
            result.type = 3
            result.val = arry[0]
        }
    }
    else if(n == 4){
        let temp = new Array(20)
        for(let i=0;i<20;i++){
            temp[i] = 0
        }
        for(let i = 0;i<n;i++){
            let cur = arry[i]
            temp[cur] += 1
        }
        console.log(temp)
        let tempSet = new Array()
        for(let i=0;i<20;i++){
            let cur = temp[i]
            if(cur>0){
                tempSet.push([i,cur])//(val,次数)
            }
        }
        if(tempSet.length == 1){//四张炸弹
            result.type = 5
            result.val = tempSet[0][0]
        }
        else if(tempSet.length == 2){//三带一
            if(tempSet[0][1] == 1 && tempSet[1][1] == 3){
                result.type = 4
                result.val = tempSet[1][0]
            }
            else if(tempSet[0][1] == 3 && tempSet[1][1] == 1){
                result.type = 4
                result.val = tempSet[0][0]
            }

        }
    }
    else if(n == 5){
        let temp = new Array(20)
        for(let i=0;i<20;i++){
            temp[i] = 0
        }
        for(let i = 0;i<n;i++){
            let cur = arry[i]
            temp[cur] += 1
        }
        console.log(temp)
        let tempSet = new Array()
        for(let i=0;i<20;i++){
            let cur = temp[i]
            if(cur>0){
                tempSet.push([i,cur])//(val,次数)
            }
        }
        if(tempSet.length == 2){//三带一对
            if(tempSet[0][1] == 2 && tempSet[1][1] == 3){
                result.type = 4
                result.val = tempSet[1][0]
            }
            else if(tempSet[0][1] == 3 && tempSet[1][1] == 2){
                result.type = 4
                result.val = tempSet[0][0]
            }
        }
    }
    if(n >= 5){
        console.log('n>=5, ->'+n)
        let t = {type:0,val:0}

        if(isShunZi(arry)){//顺子
            console.log('shunzi')
            result.type = 8
            result.val = arry[n-1]
        }
        else if(is4With2Single(arry,t)){//四带两单
            console.log('is4With2Single')
            result.type = t.type//6
            result.val = t.val
        }
        else if(is4With2Pair(arry,t)){//四带两对
            console.log('is4With2Pair')
            result.type = t.type//7
            result.val = t.val
        }
        else if(isSeqPairs(arry)){//连对
            console.log('isSeqPairs')
            result.type = 9
            result.val = arry[n-1]
        }
        else if(isAirPlane(arry,t)){//判断飞机
            console.log('isAirPlane')
            result.type = t.type
            result.val = t.val
        }
    }
    return result
}

// function singleCard(a,b) {
//     return a>b
// }

//判断是否是顺子
function isShunZi(arry) {
    let n = arry.length
    if(n <= 1){
        return false
    }
    else if(n == 2){
        return arry[1] - arry[0] == 1
    }
    else{
        let pre = arry[0]
        for(let i = 1;i<n;i++){
            let cur = arry[i]
            if(cur-pre == 1){
                pre = cur
            }
            else{
                return false
            }
        }
        return true
    }
}

//判断是否是四带2单
function is4With2Single(arry,result) {
    let n = arry.length
    var temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempSet = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
    }
    if(tempSet.length==2){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 2){
            result.type = 6
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 4){
            result.type = 6
            result.val = tempSet[1][0]
            return true
        }
    }
    else if(tempSet.length == 3){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 1 && tempSet[2][1] == 1){
            result.type = 6
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 1 && tempSet[1][1] == 4 && tempSet[2][1] == 1){
            result.type = 6
            result.val = tempSet[1][0]
            return true
        }
        else if(tempSet[0][1] == 1 && tempSet[1][1] == 1 && tempSet[2][1] == 4){
            result.type = 6
            result.val = tempSet[2][0]
            return true
        }
    }
    return false
}

//判断是否是四带2对
function is4With2Pair(arry,result) {
    let n = arry.length
    var temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempSet = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
    }
    if(tempSet.length==3){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 2 && tempSet[2][1] == 2){
            result.type = 7
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 4 && tempSet[2][1] == 2){
            result.type = 7
            result.val = tempSet[1][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 2 && tempSet[2][1] == 4){
            result.type = 7
            result.val = tempSet[2][0]
            return true
        }
    }
    return false
}

function isSeqPairs(arry){
    let n = arry.length
    if(n % 2 == 1){
        return false
    }
    console.log('n:'+n)
    let temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    console.log('temp:'+temp)
    let tempArry = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur == 0){
            continue
        }
        else if(cur == 2){
            tempArry.push(i)
        }
        else{
            return false
        }
    }
    console.log('tempArry:'+tempArry)
    if(isShunZi(tempArry)){
        console.log('true')
        return true
    }
    console.log('false')
    return false
}

function isAirPlane(arry,result) {
    console.log('isAirPlane:'+arry)
    let n = arry.length
    let temp = new Array(20)
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    console.log('isAirPlane:'+temp)
    let tempSet = new Array()
    let singleAry = new Array()
    let pairAry = new Array()
    let triAry = new Array()
    for(let i=0;i<20;i++){
        let cur = temp[i]//cur是次数
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
        if(cur == 1){
            singleAry.push(i)
        }
        else if(cur == 2){
            pairAry.push(i)
        }
        else if(cur == 3){
            triAry.push(i)
        }
        else if(cur == 4){//出现了4个，不合法
            result.type = 0
            result.val = -1
            return false
        }
    }
    console.log('sig:'+singleAry)
    console.log('par:'+pairAry)
    console.log('tri:'+triAry)
    if(triAry.length < 2){//'三张'类型的牌不足两组
        result.type = 0
        result.val = -2
    }
    else{
        let triAsc = triAry.sort()
        if(!isShunZi(triAsc)){//'三张'类型的牌不是连续
            result.type = 0
            result.val = -3
        }
        else{
            let m = triAsc.length//m >=2
            if((singleAry.length == 0 && pairAry.length == 0) || (singleAry.length == m && pairAry.length == 0) || (singleAry.length == 0 && pairAry.length == m)){
                result.type = 10
                result.val = triAsc[m-1]
                return true
            }
        }
    }
    return false
}
