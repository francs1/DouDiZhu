export default {
    name:'judgeCanPlay',
    judge(sendCards,preCards){
        if(preCards.length == 0){
            return true
        }
        else{
            let preResult = this.getType(preCards)
            let sendResult = this.getType(sendCards)
            if(sendResult.type == 5 && sendResult.val == 19){//王炸秒杀一切
                return true
            }
            if(preResult.type == 5 && preResult.val == 19){//没有人可以阻挡王炸
                return false
            }
            if(preResult.type!=0 && sendResult.type!=0 && preResult.type == sendResult.type && preCards.length == sendCards.length && preResult.val < sendResult.val){
                return true
            }
            else if(preResult.type!=0 && sendResult.type!=0 && preResult.type != 5 && sendResult.type== 5){
                return true
            }
            else{
                return false
            }
        }

    },
    getType(arry){
        let result = getCardsType(arry)
        return result
    }
    ,getTips(precardtype,owncardlist,pclen){
        let result = getCardsTip(precardtype,owncardlist,pclen)
        return result
    }
}
//牌的类型：
// 0.不符合出牌规则
// 1.单张
// 2.对子
// 3.三张
// 4.三带一(一组三张，附带任意一张单牌)
// 11.三带一对

// 8.顺子(连续单张大于等于5张)
// 9.连对(连续对子大于等于3对)

// 6.四带两单(一组四张，附带任意两张单牌)
// 7.四带两对(一组四张，附带任意两个对子)

// 10.飞机(连续三张大于等于x组，并且可附带任意y张单牌或y个对子，附带的单牌或对子不需要连续,x大于等于2，y小于等于x)
// 12.三带一飞机
// 13.三带一对飞机

// 5.炸弹
function getCardsType(arry) {
    var result = {type:0,val:0}
    var n = arry.length

    if(n == 1){//单牌
        result.type=1
        result.val=arry[0]
    }
    else if(n == 2){
        if(arry[0] == arry[1]){//对子
            result.type = 2
            result.val = arry[0]
        }
        else if((arry[0] == 18 && arry[1] == 19) || (arry[0] == 19 && arry[1] == 18)){
            //王炸
            result.type = 5
            result.val = 19
        }
    }
    else if(n == 3){
        if(arry[0] == arry[1] && arry[1] == arry[2]){//三张
            result.type = 3
            result.val = arry[0]
        }
    }
    else if(n == 4){
        let temp = new Array(20)
        for(let i=0;i<20;i++){
            temp[i] = 0
        }
        for(let i = 0;i<n;i++){
            let cur = arry[i]
            temp[cur] += 1
        }
        let tempSet = new Array()
        for(let i=0;i<20;i++){
            let cur = temp[i]
            if(cur>0){
                tempSet.push([i,cur])//(val,次数)
            }
        }
        if(tempSet.length == 1){//四张炸弹
            result.type = 5
            result.val = tempSet[0][0]
        }
        else if(tempSet.length == 2){//三带一
            if(tempSet[0][1] == 1 && tempSet[1][1] == 3){
                result.type = 4
                result.val = tempSet[1][0]
            }
            else if(tempSet[0][1] == 3 && tempSet[1][1] == 1){
                result.type = 4
                result.val = tempSet[0][0]
            }

        }
    }
    else if(n == 5){
        let temp = new Array(20)
        for(let i=0;i<20;i++){
            temp[i] = 0
        }
        for(let i = 0;i<n;i++){
            let cur = arry[i]
            temp[cur] += 1
        }
        let tempSet = new Array()
        for(let i=0;i<20;i++){
            let cur = temp[i]
            if(cur>0){
                tempSet.push([i,cur])//(val,次数)
            }
        }
        if(tempSet.length == 2){//三带一对
            if(tempSet[0][1] == 2 && tempSet[1][1] == 3){
                result.type = 11
                result.val = tempSet[1][0]
            }
            else if(tempSet[0][1] == 3 && tempSet[1][1] == 2){
                result.type = 11
                result.val = tempSet[0][0]
            }
        }
    }
    if(n >= 5){
        let t = {type:0,val:0}

        if(isShunZi(arry)){//顺子
            result.type = 8
            result.val = arry[n-1]
        }
        else if(is4With2Single(arry,t)){//四带两单
            result.type = t.type//6
            result.val = t.val
        }
        else if(is4With2Pair(arry,t)){//四带两对
            result.type = t.type//7
            result.val = t.val
        }
        else if(isSeqPairs(arry)){//连对
            result.type = 9
            result.val = arry[n-1]
        }
        else if(isAirPlane(arry,t)){//判断飞机
            result.type = t.type
            result.val = t.val
        }
    }
    return result
}

//判断是否是顺子
function isShunZi(arry) {
    let n = arry.length
    if(n <= 1){
        return false
    }
    else if(n == 2){
        return arry[1] - arry[0] == 1
    }
    else{
        let pre = arry[0]
        for(let i = 1;i<n;i++){
            let cur = arry[i]
            if(cur-pre == 1){
                pre = cur
            }
            else{
                return false
            }
        }
        return true
    }
}

//判断是否是四带2单
function is4With2Single(arry,result) {
    let n = arry.length
    var temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempSet = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
    }
    if(tempSet.length==2){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 2){
            result.type = 6
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 4){
            result.type = 6
            result.val = tempSet[1][0]
            return true
        }
    }
    else if(tempSet.length == 3){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 1 && tempSet[2][1] == 1){
            result.type = 6
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 1 && tempSet[1][1] == 4 && tempSet[2][1] == 1){
            result.type = 6
            result.val = tempSet[1][0]
            return true
        }
        else if(tempSet[0][1] == 1 && tempSet[1][1] == 1 && tempSet[2][1] == 4){
            result.type = 6
            result.val = tempSet[2][0]
            return true
        }
    }
    return false
}

//判断是否是四带2对
function is4With2Pair(arry,result) {
    let n = arry.length
    var temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempSet = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
    }
    if(tempSet.length==3){
        if(tempSet[0][1] == 4 && tempSet[1][1] == 2 && tempSet[2][1] == 2){
            result.type = 7
            result.val = tempSet[0][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 4 && tempSet[2][1] == 2){
            result.type = 7
            result.val = tempSet[1][0]
            return true
        }
        else if(tempSet[0][1] == 2 && tempSet[1][1] == 2 && tempSet[2][1] == 4){
            result.type = 7
            result.val = tempSet[2][0]
            return true
        }
    }
    return false
}

//判断是否是连对
function isSeqPairs(arry){
    let n = arry.length
    if(n % 2 == 1){
        return false
    }
    let temp = new Array()
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempArry = new Array()
    for(let i=0;i<20;i++){
        var cur = temp[i]
        if(cur == 0){
            continue
        }
        else if(cur == 2){
            tempArry.push(i)
        }
        else{
            return false
        }
    }
    if(isShunZi(tempArry)){
        return true
    }
    return false
}

//判断是否是飞机
function isAirPlane(arry,result) {
    let n = arry.length
    let temp = new Array(20)
    for(let i=0;i<20;i++){
        temp[i] = 0
    }
    for(let i = 0;i<n;i++){
        let cur = arry[i]
        temp[cur] += 1
    }
    let tempSet = new Array()
    let singleAry = new Array()
    let pairAry = new Array()
    let triAry = new Array()
    for(let i=0;i<20;i++){
        let cur = temp[i]//cur是次数
        if(cur>0){
            tempSet.push([i,cur])//(val,次数)
        }
        if(cur == 1){
            singleAry.push(i)
        }
        else if(cur == 2){
            pairAry.push(i)
        }
        else if(cur == 3){
            triAry.push(i)
        }
        else if(cur == 4){//出现了4个，不合法
            result.type = 0
            result.val = -1
            return false
        }
    }
    if(triAry.length < 2){//'三张'类型的牌不足两组
        result.type = 0
        result.val = -2
    }
    else{
        let triAsc = triAry.sort()
        if(!isShunZi(triAsc)){//'三张'类型的牌不是连续
            result.type = 0
            result.val = -3
        }
        else{
            let m = triAsc.length//m >=2
            if(singleAry.length == 0 && pairAry.length == 0){
                result.type = 10
                result.val = triAsc[m-1]
                return true
            }
            else if(singleAry.length == m && pairAry.length == 0){
                result.type = 12
                result.val = triAsc[m-1]
                return true
            }
            else if(singleAry.length == 0 && pairAry.length == m){
                result.type = 13
                result.val = triAsc[m-1]
                return true
            }
        }
    }
    return false
}


//owncardlist数据结构
/*
数组，每一个元素是这个对象
Card：
{
        id:1,
        name:'3',
        type:'hearts',
        value:3,
        img:'3hongt_Size_Format.png'
    },
*/

//*给出能否管住别人的牌的提示*
//注意：如果玩家连续出牌(其他两家都不出)，不显示提示
function  getCardsTip(precardtype,owncardlist,pclen) {
    let result = []//结果id列表
    let target = precardtype.val
    let n = owncardlist.length
    if(precardtype.type == 1 && n >= pclen){
        //在自减数组中找到比target大的最小的单牌
        for(let i=n-1;i>=0;i--){
            let cur = owncardlist[i]
            if(cur.value > target){
                result.push(cur)
                break
            }
        }
    }

    else if(precardtype.type == 2 && n >= pclen){
        //在自减数组中找到比target大的最小的对子
        for(let i=n-1;i>=1;i--){
            let cur = owncardlist[i]
            let next = owncardlist[i-1]
            if(cur.value == next.value && cur.value > target){
                result.push(cur)
                result.push(next)
                break
            }
        }
    }

    else if(precardtype.type == 3 && n >= pclen){
        //在自减数组中找到比target大的最小的三张
        for(let i=n-1;i>=2;i--){
            let cur = owncardlist[i]
            let next = owncardlist[i-1]
            let nextnext = owncardlist[i-2]
            if(cur.value == next.value && next.value == nextnext.value && cur.value > target){
                result.push(cur)
                result.push(next)
                result.push(nextnext)
                break
            }
        }
    }
    else if(precardtype.type == 4 && n >= pclen){//三带1
        for(let i=n-1;i>=2;i--){
            let cur = owncardlist[i]
            let next = owncardlist[i-1]
            let nextnext = owncardlist[i-2]
            if(cur.value == next.value && next.value == nextnext.value && cur.value > target){
                result.push(cur)
                result.push(next)
                result.push(nextnext)
                if(i!= n-1){
                    result.push(owncardlist[n-1])
                }
                else{
                    result.push(owncardlist[n-4])
                }
                break
            }
        }
    }
    else if(precardtype.type == 11 && n >= pclen){//三带一对
        for(let i=n-1;i>=2;i--){
            let cur = owncardlist[i]
            let next = owncardlist[i-1]
            let nextnext = owncardlist[i-2]
            if(cur.value == next.value && next.value == nextnext.value && cur.value > target){

                let findpair = false
                for(let j=n-1;j>1;j--){
                    let tcur = owncardlist[j]
                    let tnext = owncardlist[j-1]
                    if(tcur.value == tnext.value && tcur.value != cur.value){
                        result.push(tcur)
                        result.push(tnext)
                        findpair = true
                        break
                    }
                }

                if(findpair){
                    result.push(cur)
                    result.push(next)
                    result.push(nextnext)
                }
                break
            }
        }
    }
    else if(precardtype.type == 5 && n >= 2){//炸弹
        result = palyzhadan(owncardlist,target,n)
    }
    else if(precardtype.type == 8 && n >= pclen){//顺子
        let valueset = new Set()
        for(let i = n-1;i>=0;i--){
            valueset.add(owncardlist[i].value)
        }
        let valueAry = new Array()
        valueset.forEach(s=>valueAry.push(s))
        valueAry = valueAry.sort(ascOrder)
        console.log('valueAry='+valueAry)
        for(let j=0;j<valueAry.length-pclen;j++){
            let slice = valueAry.slice(j,j+pclen)
            console.log('slice='+slice)
            if(isShunZi(slice) && slice[pclen-1] > target){
                let count = 0
                for(let k=n-1;k>=0;k--){
                    if(owncardlist[k].value == slice[count]){
                        result.push(owncardlist[k])
                        count++
                    }
                }
                break
            }
        }

    }
    else if(precardtype.type == 9 && n >= pclen){//连对
        let m = pclen / 2 //连对是几个对子
        let countMap = new Map()

        for(let i = n-1;i>=0;i--){
            if(!countMap.has(owncardlist[i].value)){
                countMap.set(owncardlist[i].value,1)
            }
            else{
                let ct = countMap.get(owncardlist[i].value)
                countMap.set(owncardlist[i].value,ct+1)
            }
        }

        let valueAry = new Array()
        countMap.forEach((v,k)=> {
            if(v >= 2){
                valueAry.push(k)
            }
        })

        valueAry = valueAry.sort(ascOrder)
        console.log('valueAry='+valueAry)
        if(valueAry.length >= m){
            for(let j=0;j<valueAry.length-m;j++){
                let slice = valueAry.slice(j,j+m)
                console.log('slice='+slice)
                if(isShunZi(slice) && slice[m-1] > target){
                    let count = 0
                    for(let k=n-1;k>=0;k--){
                        if(owncardlist[k].value == slice[count]){
                            result.push(owncardlist[k])
                            result.push(owncardlist[k-1])
                            k -= 1
                            count++
                        }
                    }
                    break
                }
            }
        }
    }

    if(result.length == 0){
        result = palyzhadan(owncardlist,target,n)
    }
    /*
    else if(precardtype.type == 6){

    }
    else if(precardtype.type == 7){

    }

    else if(precardtype.type == 10){

    }

    else if(precardtype.type == 12){

    }
    else if(precardtype.type == 13){

    }
    //同级别找不到，再寻找炸弹
*/
    return result//是owncardlist的一个子集
}

function palyzhadan(owncardlist,target,n) {
    let result = []
    if(n >= 2){//炸弹
        if(owncardlist[0].value == 19 && owncardlist[1].value == 18){//先出王炸
            result.push(owncardlist[0])
            result.push(owncardlist[1])
        }
        else if(n >= 4){
            for(let i=n-1;i>=3;i--){
                let cur = owncardlist[i]
                let next = owncardlist[i-1]
                let nextnext = owncardlist[i-2]
                let nextnextnext = owncardlist[i-3]
                if(cur.value == next.value && next.value == nextnext.value && nextnext.value == nextnextnext.value && cur.value > target){
                    result.push(cur)
                    result.push(next)
                    result.push(nextnext)
                    result.push(nextnextnext)
                    break
                }
            }
        }
    }
    return result
}

function ascOrder(x,y){
    if (x > y){
        return 1
    }
    else if (y > x){
        return -1
    }
    else{
        return 0
    }
}
