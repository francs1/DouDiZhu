<template>
    <input type="button" value="开始游戏" @click="connection">
</template>

<script>
    import Vuex from 'vuex'
    export default {
        name: "PlayDesktop",
        data(){
            return {}
        },
        methods:{
            connection(){
                if("WebSocket" in window){
                    console.log('支持WebSocket')
                    var ws = new WebSocket('ws://192.168.0.101:8001')
                    ws.onopen = function (e) {
                        console.log("连接服务器"+e)
                        var data = {
                            username:'yangasen',
                            option:'conn'
                        }
                        var msg = JSON.stringify(data)
                        ws.send(msg)
                    }
                    ws.onclose = function (e) {
                        console.log("服务器关闭"+e)
                    }
                    ws.onerror = function () {
                        console.log("连接出错")
                    }
                    ws.onmessage = function (e) {
                        //console.log(resp)
                        var resp = JSON.parse(e.data)
                        console.log(resp)
                        //console.log(resp)
                        //this.$store.state.resp = resp
                        console.log(this.$store)
                    }
                }
                else{
                    console.log('不能使用WebSocket')
                }
            }
        }
    }
</script>

<style scoped>

</style>
