<template>
  <div id="app">
      <div style="display: inline-block;width:1000px;" v-if="notbegin">
        用户名：<input id="ddz_username" ref="ddz_username" type="text" v-model="username" />
        房间号：<input type="text" v-model="roomid" />
        <input type="button" value="开始游戏" class="optbtn2" @click="connection" />
        <input type="button" value="重载界面" class="optbtnon2" @click="refresh" />
      </div>
      <div style="display: inline-block;" v-if="! notbegin">
        <input type="button" value="结束游戏" class="optbtnon2" @click="disconnection">
      </div>
      <div style="display: inline-block" v-if="!notbegin">{{title}}</div>
      <div style="display: inline-block" v-if="!notbegin">{{username}}</div>
      <div id="outer">
          <div class="up">
              <div class="bottom">
                  <ul class="ot_mid_ul">
                      <li class="ot_mid_li" v-for="(item) in this.bottomcardlist" :key="item.id">
                          <div class="ot_mid_card_choose">
                              <img :src="item.img" class="ot_cardimg" />
                          </div>
                      </li>
                  </ul>
              </div>
          </div>
          <div class="in">
              <div class="left">
                  <div>
                    <span>上家:</span>
                    <span>{{leftplayer.username}}</span>|
                      <span v-if="leftplayer.landload" class="landload">地主</span>
                      <span v-if="!leftplayer.landload" class="farmers">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span class="restcount">{{leftplayer.cardlist.length}}</span>
                  </div>
                  <div>
                      <div v-if="!notbegin">
                          <span class="noplay" v-if="(leftplayer.precardlist.length==0 && !gameover)">不出</span>
                      </div>
                      <ul class="ot_mid_ul">
                          <li class="ot_mid_li" v-for="(item) in leftplayer.precardlist" :key="item.id">
                              <div class="ot_mid_card_choose" :id="item.id">
                                  <img :src="item.img" class="ot_cardimg" />
                              </div>
                          </li>
                      </ul>
                  </div>
              </div>

              <div v-show="gameover" class="gameover">
                  <span v-if="landloadwin">地主获胜</span>
                  <span v-if="!landloadwin">农民获胜</span>
                  <span><img :src="resultimg" class="resimg" /></span>
              </div>

              <div class="right">
                  <div>
                      <span>下家:</span>
                      <span>{{rightplayer.username}}</span>|
                      <span v-if="rightplayer.landload" class="landload">地主</span>
                      <span v-if="!rightplayer.landload" class="farmers">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span class="restcount">{{rightplayer.cardlist.length}}</span>
                  </div>
                  <div>
                      <div v-if="!notbegin">
                          <span class="noplay" v-if="(rightplayer.precardlist.length==0 && !gameover)">不出</span>
                      </div>
                      <ul class="ot_mid_ul">
                          <li class="ot_mid_li" v-for="(item) in rightplayer.precardlist" :key="item.id">
                              <div class="ot_mid_card_choose" :id="item.id">
                                  <img :src="item.img" class="ot_cardimg" />
                              </div>
                          </li>
                      </ul>
                  </div>
              </div>

          </div>

          <div class="down">
              <div class="mid_cont" v-if="(activity && !gameover)">
                  <div class="mid_cont_div">
                    <input type="button" value="出牌" @click="play" class="optbtn"><span style="width:25px;display: inline-block"></span>
                    <input type="button" value="不出" @click="no" class="optbtnon" v-if="((preclientid!='')&&(preclientid != clientid))">
                    <span style="width:25px;display: inline-block"></span>
                    <input type="button" value="提示" @click="tips" class="optbtnon" v-if="((preclientid!='')&&(preclientid != clientid))">&nbsp;
                  </div>
              </div>
              <div class="middle">
                  <div>
                      <span class="noplay">{{cardtips}}</span>
                      <span>本家:</span>
                      <span>{{midplayer.username}}</span>|
                      <span v-if="midplayer.landload" class="landload">地主</span>
                      <span v-if="!midplayer.landload" class="farmers">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span class="restcount">{{midplayer.cardlist.length}}</span>
                  </div>
                  <div v-if="(!activity && !noplay)" id="myplayedlist">
                      <ul class="ot_mid_ul">
                          <li class="ot_mid_li" v-for="(item) in midplayer.precardlist" :key="item.id">
                              <div class="ot_mid_card_choose" :id="item.id">
                                  <img :src="item.img" class="ot_cardimg" />
                              </div>
                          </li>
                      </ul>
                  </div>
                  <div style="margin-top: 10px;">
                  <div class="mid_div_out">
                      <div class="mid_div_in" v-for="(item,index) in this.owncardlist" :key="item.id" :style="{'z-index':index}">
                          <img class="mid_card" :src="item.img" :id="item.id" @click="change(item.id,item.value)" />
                      </div>
                  </div>
                  </div>
              </div>

          </div>

      </div>
      <div>
          <div>

          </div>
      </div>
      <span>
          <audio :src="music" autoplay controls :loop="loop"></audio>
      </span>
      <span>
          <audio :src="sound" autoplay></audio>
      </span>
  </div>

</template>

<script>
import judgeCanPlay from './judgeCanPlay.js'
import $ from 'jquery'
import Cookie from 'js-cookie'
export default {

  name: 'App',
    data(){
      return {
          ws:null,//websokcet 连接实例
          owncardlist:[],//自己的牌
          bottomcardlist:[],//底牌
          sendcards:[],//自己打算出的牌
          precards:[],//前一位玩家出的牌
          preclientid:'',//上一位出牌的玩家的客户端id
          notbegin:true,//是否没有开始游戏
          username:'',//用户名
          roomid:0,//房间号
          title:'',//标题
          clientid:'',//客户端id
          activity:false,//是否当前出牌
          noplay:false,//是否不出牌
          landload:false,//是否是地主
          cardtips:'',//卡牌提示
          leftplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false},//上家
          rightplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false,},//下家
          midplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false,},//玩家自己
          gameover:false,//游戏是否结束
          landloadwin:true,//是否是地主获胜
          music: require("@/assets/music/welcome.mp3"),//背景音乐
          sound:'',//打出的牌的语音
          loop:true,//音乐是否循环
          ex:false,//是否已经打出炸弹，音乐换成了exciting.mp3
          resultimg:'',//游戏结束，是胜利还是失败的图片
          mustplay:false
      }
    },
  components: {

  },
    methods:{
        play(){
            let ascAry = new Array()
            for(let i=0;i<this.sendcards.length;i++){
                ascAry.push(this.sendcards[i][1])
            }
            ascAry = ascAry.sort(this.ascOrder)
            let cardtype = judgeCanPlay.getType(ascAry)

            if(cardtype.type == 0){
                ascAry = []
                this.clear()
                this.cardtips = '不符合出牌规则'
                return
            }
            let ascPre = new Array()
            for(let i=0;i<this.precards.length;i++){
                ascPre.push(this.precards[i].value)
            }
            ascPre = ascPre.sort(this.ascOrder)

            if(ascAry.length!=0){

                let canplay = false
                if(this.preclientid == '' || this.preclientid == this.clientid){//自己连续出牌
                   canplay = true
                }
                else if(ascPre.length == 0){
                    canplay = true
                }
                else if(judgeCanPlay.judge(ascAry,ascPre)){//自己比上一个玩家的牌大
                    canplay = true
                }
                //canplay = true 调试使用
                if(canplay){
                    this.cardtips = ''
                    this.preclientid = this.clientid
                    var client = this.ws
                    var data = {
                        username:this.username,
                        roomid:this.roomid,
                        sendcards:this.sendcards,
                        option:'play',
                        cardtype:cardtype.type,
                        cardval:cardtype.val,
                    }
                    var msg = JSON.stringify(data)
                    client.send(msg)
                    this.activity=false
                    this.noplay = false
                    this.clear()
                }
                else{
                    this.cardtips = '您的牌管不住上一个玩家'
                    this.clear()
                }

            }
        },
        clear(){
            this.sendcards = []
            //$('.mid_li > div').attr('class','mid_card')
            $('.mid_div_in > img').attr('class','mid_card')
        },
        init(){
            this.owncardlist=[]//自己的牌
            this.bottomcardlist=[]//底牌
            this.sendcards=[]//自己打算出的牌
            this.precards=[]//前一位玩家出的牌
            this.preclientid=''//上一位出牌的玩家的客户端id
            this.notbegin=true//是否没有开始游戏
            this.clientid=''//客户端id
            this.leftplayer={id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false}//上家
            this.rightplayer={id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false,}//下家
            this.midplayer={id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false,}//玩家自己
        },
        no(){
            this.cardtips = '不出'
            this.noplay=true
            var client = this.ws
            var data = {
                username:this.username,
                roomid:this.roomid,
                precards:this.precards,
                preclientid:this.preclientid,
                option:'no'
            }
            var msg = JSON.stringify(data)
            client.send(msg)
            this.activity=false
            this.clear()
        },
        tips(){//preclientid != '' && preclientid != clientid
            let ascPre = new Array()
            for(let i=0;i<this.precards.length;i++){
                ascPre.push(this.precards[i].value)
            }
            ascPre = ascPre.sort(this.ascValueOrder)

            let precardtype = judgeCanPlay.getType(ascPre)
            console.log('precardtype:'+JSON.stringify(precardtype))
            let tipsresult = judgeCanPlay.getTips(precardtype,this.owncardlist,this.precards.length)
            if(tipsresult.length>0){
                this.clear()//清空已经选择的牌
                tipsresult.forEach(card=>this.change(card.id,card.value))//选中提示的牌
            }
            else{
                this.cardtips = '没有建议的牌'
            }
        },
        randomSound(){
            let code = Math.floor(Math.random()*2)
            if(code == 0){
                return require('@/assets/sounds/04/guanshang.mp3')
            }
            else{
                return require('@/assets/sounds/04/dani.mp3')
            }
        },
        ascOrder(x,y){
            if (x > y){
                return 1
            }
            else if (y > x){
                return -1
            }
            else{
                return 0
            }
        },
        ascValueOrder(x,y){
            if (x.value > y.value){
                return 1
            }
            else if (y.value > x.value){
                return -1
            }
            else{
                return 0
            }
        },
        change(id,val){
            let classname = document.getElementById(id).className
            if(classname == "mid_card_choose"){
                //$('#'+id).css('margin-top','20px')
                document.getElementById(id).className = "mid_card"
            }
            else {
                //document.getElementById(id).className = "mid_card_choose"
                //$('#'+id).css('margin-top','0')
                document.getElementById(id).className = "mid_card_choose"
            }
            let notexist= true
            for(let i =0;i<this.sendcards.length;i++){
                let cur_id = this.sendcards[i][0]
                if(cur_id == id){
                    this.sendcards.splice(i,1)
                    notexist = false
                    break
                }
            }
            if(notexist){
                this.sendcards.push([parseInt(id),parseInt(val)])
            }
        },
        connection(){
            if(this.username != ''){
                Cookie.set('ddz_username',this.username)
            }
            if(this.roomid != undefined){
                Cookie.set('ddz_roomid',this.roomid)
            }
            if("WebSocket" in window){
                this.gameover=false
                //this.ws = new WebSocket('ws://192.168.0.102:8001')
                this.ws = new WebSocket('ws://47.95.38.145:8001')
                let client = this.ws
                let context = this
                this.ws.onopen = function (e) {
                    console.log("连接服务器"+JSON.stringify(e))
                    let data = {
                        username:context.username,
                        roomid:context.roomid,
                        option:'conn'
                    }
                    let msg = JSON.stringify(data)
                    client.send(msg)
                }
                this.ws.onclose = function () {
                    console.log("服务器关闭")
                }
                this.ws.onerror = function () {
                    console.log("连接出错")
                }
                this.ws.onmessage = function (e) {
                    let resp = JSON.parse(e.data)
                    if(resp.resulttype == 0){
                        context.title = '等待其它玩家...'
                        if(context.clientid == ''){
                            context.clientid = resp.clientid
                        }
                    }
                    else if(resp.resulttype == 1){
                        context.title = '游戏已开始~~~'
                        if(!context.ex){
                            context.music = require("@/assets/music/normal.mp3")
                        }
                        if(context.clientid == ''){
                            context.clientid = resp.clientid
                        }
                        resp.cardlist.forEach(function (r,i) {
                            if(r.id == context.clientid){
                                context.landload=r.landload
                                context.owncardlist = r.cardlist

                                context.owncardlist.forEach(function(p){
                                    p.img = require("@/assets/target/"+p.img)
                                })

                                context.activity = r.activity
                                if(i == 0){
                                    //自己是0，上家是2，下家是1
                                    context.midplayer = resp.cardlist[0]
                                    context.leftplayer = resp.cardlist[2]
                                    context.rightplayer = resp.cardlist[1]
                                }
                                else if(i == 1){
                                    //自己是1，上家是0，下家是2
                                    context.midplayer = resp.cardlist[1]
                                    context.leftplayer = resp.cardlist[0]
                                    context.rightplayer = resp.cardlist[2]
                                }
                                else if(i == 2){
                                    //自己是2，上家是1，下家是0
                                    context.midplayer = resp.cardlist[2]
                                    context.leftplayer = resp.cardlist[1]
                                    context.rightplayer = resp.cardlist[0]
                                }
                                context.midplayer.precardlist.forEach((v)=>{
                                    v.img = require("@/assets/target/"+v.img)
                                })
                                context.leftplayer.precardlist.forEach((v)=>{
                                    v.img = require("@/assets/target/"+v.img)
                                })
                                context.rightplayer.precardlist.forEach((v)=>{
                                    v.img = require("@/assets/target/"+v.img)
                                })

                            }
                        })
                        if(context.landload){
                            context.title = '地主'
                        }
                        else{
                            context.title = '农民'
                        }

                        if(resp.bottom){
                            context.bottomcardlist = resp.bottom
                            context.bottomcardlist.forEach(function(p){
                                p.img = require("@/assets/target/"+p.img)
                            })

                        }
                        if(resp.precards){
                            context.precards = resp.precards
                            context.precards.forEach(function(p){
                                p.img = require("@/assets/target/"+p.img)
                            })
                        }
                        if(resp.preclientid){
                            context.preclientid = resp.preclientid
                        }
                        if(resp.cardtype == 0){
                            if(resp.cardval == 0){
                                context.sound = require("@/assets/sounds/05/buyao.mp3")
                            }
                            else if(resp.cardval == 1){
                                context.sound = require("@/assets/sounds/05/guo.mp3")
                            }
                            else if(resp.cardval == 2){
                                context.sound = require("@/assets/sounds/05/pass.mp3")
                            }
                            else{
                                context.sound = require("@/assets/sounds/05/yaobuqi.mp3")
                            }
                        }
                        else if(resp.cardtype == 1){
                            if(resp.cardval == 3){
                                context.sound = require("@/assets/sounds/01/03.mp3")
                            }
                            if(resp.cardval == 4){
                                context.sound = require("@/assets/sounds/01/04.mp3")
                            }
                            if(resp.cardval == 5){
                                context.sound = require("@/assets/sounds/01/05.mp3")
                            }
                            if(resp.cardval == 6){
                                context.sound = require("@/assets/sounds/01/06.mp3")
                            }
                            if(resp.cardval == 7){
                                context.sound = require("@/assets/sounds/01/07.mp3")
                            }
                            if(resp.cardval == 8){
                                context.sound = require("@/assets/sounds/01/08.mp3")
                            }
                            if(resp.cardval == 9){
                                context.sound = require("@/assets/sounds/01/09.mp3")
                            }
                            if(resp.cardval == 10){
                                context.sound = require("@/assets/sounds/01/10.mp3")
                            }
                            if(resp.cardval == 11){
                                context.sound = require("@/assets/sounds/01/J.mp3")
                            }
                            if(resp.cardval == 12){
                                context.sound = require("@/assets/sounds/01/Q.mp3")
                            }
                            if(resp.cardval == 13){
                                context.sound = require("@/assets/sounds/01/K.mp3")
                            }
                            if(resp.cardval == 14){
                                context.sound = require("@/assets/sounds/01/A.mp3")
                            }
                            if(resp.cardval == 16){
                                context.sound = require("@/assets/sounds/01/02.mp3")
                            }
                            if(resp.cardval == 18){
                                context.sound = require("@/assets/sounds/01/xiaow.mp3")
                            }
                            if(resp.cardval == 19){
                                context.sound = require("@/assets/sounds/01/daw.mp3")
                            }
                        }
                        else if(resp.cardtype == 2){
                            if(resp.cardval == 3){
                                context.sound = require("@/assets/sounds/02/dui03.mp3")
                            }
                            if(resp.cardval == 4){
                                context.sound = require("@/assets/sounds/02/dui04.mp3")
                            }
                            if(resp.cardval == 5){
                                context.sound = require("@/assets/sounds/02/dui05.mp3")
                            }
                            if(resp.cardval == 6){
                                context.sound = require("@/assets/sounds/02/dui06.mp3")
                            }
                            if(resp.cardval == 7){
                                context.sound = require("@/assets/sounds/02/dui07.mp3")
                            }
                            if(resp.cardval == 8){
                                context.sound = require("@/assets/sounds/02/dui08.mp3")
                            }
                            if(resp.cardval == 9){
                                context.sound = require("@/assets/sounds/02/dui09.mp3")
                            }
                            if(resp.cardval == 10){
                                context.sound = require("@/assets/sounds/02/dui10.mp3")
                            }
                            if(resp.cardval == 11){
                                context.sound = require("@/assets/sounds/02/duiJ.mp3")
                            }
                            if(resp.cardval == 12){
                                context.sound = require("@/assets/sounds/02/duiQ.mp3")
                            }
                            if(resp.cardval == 13){
                                context.sound = require("@/assets/sounds/02/duiK.mp3")
                            }
                            if(resp.cardval == 14){
                                context.sound = require("@/assets/sounds/02/duiA.mp3")
                            }
                            if(resp.cardval == 16){
                                context.sound = require("@/assets/sounds/02/dui02.mp3")
                            }
                        }
                        else if(resp.cardtype == 3){
                            if(resp.cardval == 3){
                                context.sound = require("@/assets/sounds/03/san03.mp3")
                            }
                            if(resp.cardval == 4){
                                context.sound = require("@/assets/sounds/03/san04.mp3")
                            }
                            if(resp.cardval == 5){
                                context.sound = require("@/assets/sounds/03/san05.mp3")
                            }
                            if(resp.cardval == 6){
                                context.sound = require("@/assets/sounds/03/san06.mp3")
                            }
                            if(resp.cardval == 7){
                                context.sound = require("@/assets/sounds/03/san07.mp3")
                            }
                            if(resp.cardval == 8){
                                context.sound = require("@/assets/sounds/03/san08.mp3")
                            }
                            if(resp.cardval == 9){
                                context.sound = require("@/assets/sounds/03/san09.mp3")
                            }
                            if(resp.cardval == 10){
                                context.sound = require("@/assets/sounds/03/san10.mp3")
                            }
                            if(resp.cardval == 11){
                                context.sound = require("@/assets/sounds/03/sanJ.mp3")
                            }
                            if(resp.cardval == 12){
                                context.sound = require("@/assets/sounds/03/sanQ.mp3")
                            }
                            if(resp.cardval == 13){
                                context.sound = require("@/assets/sounds/03/sanK.mp3")
                            }
                            if(resp.cardval == 14){
                                context.sound = require("@/assets/sounds/03/sanA.mp3")
                            }
                            if(resp.cardval == 16){
                                context.sound = require("@/assets/sounds/03/san02.mp3")
                            }
                        }
                        else if(resp.cardtype == 4){//三带一
                            let newsound = require("@/assets/sounds/04/sandai01.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 11){//三带一对
                            let newsound = require("@/assets/sounds/04/sandai02.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 5){
                            if(resp.cardval == 19){
                                context.sound = require("@/assets/sounds/02/wangzha.mp3")
                            }
                            else{
                                context.sound = require("@/assets/sounds/04/zhadan.mp3")
                            }
                            if(!context.ex){
                                context.ex = true
                                context.music = require("@/assets/music/exciting.mp3")
                            }
                        }
                        else if(resp.cardtype == 6){
                            let newsound = require("@/assets/sounds/04/sidai02.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 7){
                            let newsound = require("@/assets/sounds/04/sidai22.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 8){
                            let newsound = require("@/assets/sounds/04/shunzi.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 9){
                            let newsound = require("@/assets/sounds/04/liandui.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }
                        else if(resp.cardtype == 10 || resp.cardtype == 12 || resp.cardtype == 13){
                            let newsound = require("@/assets/sounds/04/feiji.mp3")
                            if(newsound == context.sound){
                                context.sound = context.randomSound()
                            }
                            else{
                                context.sound = newsound
                            }
                        }

                        if(resp.gameover){
                            context.gameover = true
                            context.landloadwin = resp.landloadwin

                            if(resp.landloadwin == context.landload){
                                context.music = require("@/assets/music/win.mp3")
                                context.loop = false
                                context.resultimg = require("@/assets/shengli.png")
                            }
                            else{
                                context.music = require("@/assets/music/lose.mp3")
                                context.loop = false
                                context.resultimg = require("@/assets/shibai.png")
                            }
                            let client = context.ws
                            let data = {
                                username:context.username,
                                roomid:context.roomid,
                                option:'close'
                            }
                            let msg = JSON.stringify(data)
                            client.send(msg)
                            console.log('websocket 已关闭')
                            context.init()
                        }

                    }
                }
            }
            else{
                console.log('不能使用WebSocket')
            }
            this.notbegin = false
        },
        disconnection(){
            let client = this.ws
            let data = {
                username:this.username,
                roomid:this.roomid,
                option:'close'
            }
            let msg = JSON.stringify(data)
            client.close(1000,msg)
            window.location.href = window.location
        },
        refresh(){
            window.location.href = window.location
        }
    },
    created() {
        if(Cookie.get('ddz_username')) {
            this.username = Cookie.get('ddz_username')
        }
        if(Cookie.get('ddz_roomid')) {
            this.roomid = Cookie.get('ddz_roomid')
        }
    }
}
</script>

<style lang="less">
    body{
        margin-top: 0;
        background-color: azure;
    }
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.logo{
    font-size:48px;
    color:red;
}
    .mid_ul{
        list-style: none;
        margin-left: 0px;
        height: 134px;
        line-height: 134px;
        border: solid 0px red;
        margin-top: 0;
        margin-bottom: 0;
    }
    .ot_mid_ul{
        list-style: none;
        margin-left: 0px;
        height: 100px;
        line-height: 100px;
        border: solid 0px red;
        margin-top: 0;
        margin-bottom: 0;
    }
    .mid_li{
         display: inline-block;
         line-height: 134px;
         width:88px;
         height:134px;
         border: solid 0px red;
         margin-left:-50px;
     }
    .mid_div_out{
        margin: 0;
        padding: 0;
        height: 160px;
        line-height: 160px;
        outline: solid 0px red;
    }
    .mid_div_in{
        display: inline-block;
        line-height: 154px;
        width:88px;
        height:160px;
        line-height: 160px;
        outline: solid 0px black;
        margin-left:-50px;
    }
    .mid_div_in > img{
        outline: solid 1px black;
    }
    .ot_mid_li{
        display: inline-block;
        line-height: 100px;
        width:66px;
        height:134px;
        border: solid 0px red;
        margin-left:-35px;
    }
    .mid_card{
        border:solid 0px gray;
        width:88px;
        height:134px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 134px;
        float: left;
        margin-top: 20px;
    }
    .ot_mid_card{
        border:solid 0px gray;
        width:66px;
        height:100px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 100px;
    }
    .mid_card_choose{
        border:solid 0px orange;
        width:88px;
        height:134px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 134px;
        float: left;
        margin-top: 0;
    }
    .ot_mid_card_choose{
        border:solid 0px orange;
        width:66px;
        height:100px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 100px;
    }
    .ot_mid_card_choose > img{
        outline: solid 1px black;
    }
    .card{
        border:solid 0px gray;
        width:88px;
        height:134px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 134px;
        display: inline-block;
    }
    .cardimg{
        width:88px;
        height:134px;
    }
    .ot_cardimg{
        width:66px;
        height:100px;
    }
    #outer{
        border:solid 0px gray;
        width:1000px;
        margin: 0 auto;
        text-align: center
    }
    .up{
        border:solid 0px red;
        width:400px;
        margin: 0 auto;
        text-align: center
    }
    .bottom{
        width:200px;
        margin: 0 auto;
        text-align: center
    }
    .in{
        border: solid 0px green;
        width:998px;
        height:150px;
    }
    .left{
        border: solid 0px blue;
        width:340px;
        height:200px;
        float: left;
    }
    .gameover{
        width:300px;
        height:120px;
        border:solid 0px red;
        float:left;
        text-align: center;
        padding-top: 30px;
    }
    .right{
        border:solid 0px cyan;
        width:340px;
        height:200px;
        float: right;
    }
    .down{
        border: solid 0px green;
        width:998px;
        margin-top: 5px;
    }
    .mid_cont{
        width:998px;
        height: 40px;
    }
    .mid_cont_div{
        border:solid 0px orange;
        width:250px;
        height: 40px;
        margin: 0 auto;
        text-align: center
    }

    .middle{
        border: solid 0px orange;
        width:998px;
        padding-bottom: 10px;
    }
    .noplay{
        width:50px;
        height:25px;
        font-size: 25px;

    }
    .optbtn{
        width:50px;
        height:40px;
        line-height: 40px;
        background-color:royalblue;
        color:white;
        cursor: pointer;
        font-weight:bolder;
    }
    .optbtn2{
        width:80px;
        height:40px;
        line-height: 40px;
        background-color:royalblue;
        color:white;
        cursor: pointer;
        font-weight:bolder;
    }
    .optbtnon{
        width:50px;
        height:40px;
        line-height: 40px;
        background-color:orange;
        color:white;
        cursor: pointer;
        font-weight:bolder;
    }
    .optbtnon2{
        width:80px;
        height:40px;
        line-height: 40px;
        background-color:orange;
        color:white;
        cursor: pointer;
        font-weight:bolder;
    }
    .resimg{
        width:256px;
        height:72px;
    }
    .farmers{
        background-color: lightblue;
        color: black;
        font-weight: bolder;
    }
    .landload{
        background-color: red;
        color:white;
        font-weight: bolder;
    }
    .restcount{
        background-color: black;
        color:white;
        font-weight: bolder;
    }
</style>
