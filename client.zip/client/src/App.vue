<template>
  <div id="app">
      <div class="logo">小森斗地主</div>
      <span v-if="notbegin">
        用户名：<input type="text" v-model="username" />
        房间号：<input type="text" v-model="roomid" />
        <input type="button" value="开始游戏" @click="connection()">
      </span>
      <span v-if="! notbegin">
        <input type="button" value="结束游戏" @click="disconnection">
      </span>
      <span>{{title}}</span>
      <span>{{clientid}}</span>
      <div id="outer">
          <div class="up">
              <div class="bottom">
                  <ul class="mid_ul">
                      <li class="mid_li" v-for="(item) in this.bottomcardlist" :key="item.id">
                          <span class="card">{{ item.name}} </span>
                      </li>
                  </ul>
              </div>
          </div>
          <div class="in">
              <div class="left">
                  <div>
                    <span>上家:</span>
                    <span>{{leftplayer.username}}</span>|
                      <span v-if="leftplayer.landload">地主</span>
                      <span v-if="!leftplayer.landload">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span>{{leftplayer.cardlist.length}}</span>
                  </div>
                  <div>
                      <ul class="mid_ul">
                          <li class="mid_li" v-for="(item) in leftplayer.precardlist" :key="item.id">
                              <div :class="mid_card_choose" :id="item.id">
                                  <span>{{ item.name }}</span>
                              </div>
                          </li>
                      </ul>
                  </div>
              </div>
              <div class="right">
                  <div>
                      <span>下家:</span>
                      <span>{{rightplayer.username}}</span>|
                      <span v-if="rightplayer.landload">地主</span>
                      <span v-if="!rightplayer.landload">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span>{{rightplayer.cardlist.length}}</span>
                  </div>
                  <div>
                      <ul class="mid_ul">
                          <li class="mid_li" v-for="(item) in rightplayer.precardlist" :key="item.id">
                              <div :class="mid_card_choose" :id="item.id">
                                  <span>{{ item.name }}</span>
                              </div>
                          </li>
                      </ul>
                  </div>
              </div>

          </div>
          <div v-if="gameover" class="gameover">
              <span v-if="landloadwin">地主获胜</span>
              <span v-if="!landloadwin">农民获胜</span>
          </div>
          <div class="down">
              <div class="mid_show"></div>
              <div class="mid_cont" v-if="activity">
                  <input type="button" value="出牌" @click="play">
                  <input type="button" value="不出" @click="no">
                  <input type="button" value="清空" @click="clear">
              </div>
              <div class="middle">
                  <div>
                      <span>{{cardtips}}</span>
                      <span>本家:</span>
                      <span>{{midplayer.username}}</span>|
                      <span v-if="midplayer.landload">地主</span>
                      <span v-if="!midplayer.landload">农民</span>
                  </div>
                  <div>
                      <span>剩余牌数量:</span>
                      <span>{{midplayer.cardlist.length}}</span>
                  </div>
                  <div>
                      <ul class="mid_ul">
                          <li class="mid_li" v-for="(item) in midplayer.precardlist" :key="item.id">
                              <div :class="mid_card_choose" :id="item.id">
                                  <span>{{ item.name }}</span>
                              </div>
                          </li>
                      </ul>
                  </div>
                  <ul class="mid_ul">
                      <li class="mid_li" v-for="(item) in this.owncardlist" :key="item.id">
                          <div :class="mid_card" :id="item.id" @click="change(item.id,item.value)">
                              <span>{{ item.name}}</span>
                          </div>
                      </li>
                  </ul>
              </div>

          </div>

      </div>

  </div>
</template>

<script>
import judgeCanPlay from './judgeCanPlay.js'
import $ from 'jquery'
export default {

  name: 'App',
    data(){
      return {
          ws:null,//websokcet 连接实例
          mid_card:"mid_card",//普通样式
          mid_card_choose:"mid_card_choose",//选中样式
          owncardlist:[],//自己的牌
          bottomcardlist:[],//底牌
          sendcards:[],//自己打算出的牌
          precards:[],//前一位玩家出的牌
          preclientid:'',//上一位出牌的玩家的客户端id
          notbegin:true,
          username:'player01',//用户名
          roomid:0,//房间号
          title:'',//标题
          clientid:'',//客户端id
          activity:false,//是否当前出牌
          landload:false,//是否是地主
          cardtips:'',
          leftplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false},//上家
          rightplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false},//下家
          midplayer:{id:'',username:'',cardlist:[],activity:false,precardlist:[],landload:false},//玩家自己
          gameover:false,
          landloadwin:true,
      }
    },
  components: {

  },
    methods:{
        play(){
            let ascAry = new Array()
            for(let i=0;i<this.sendcards.length;i++){
                ascAry.push(this.sendcards[i][1])
            }
            ascAry = ascAry.sort(this.ascOrder)
            let cardtype = judgeCanPlay.getType(ascAry)

            if(cardtype.type == 0){
                ascAry = []
                this.clear()
                this.cardtips = '不符合出牌规则'
                return
            }
            let ascPre = new Array()
            for(let i=0;i<this.precards.length;i++){
                ascPre.push(this.precards[i][1])
            }
            ascPre = ascPre.sort(this.ascOrder)

            if(this.sendcards.length!=0){
                let canplay = false
                if(this.preclientid == '' || this.preclientid == this.clientid){//自己连续出牌
                   canplay = true
                }
                else if(judgeCanPlay.judge(ascAry,ascPre)){//自己比上一个玩家的牌大
                    canplay = true
                }
                if(canplay){
                    this.cardtips = ''
                    this.preclientid = this.clientid
                    var client = this.ws
                    var data = {
                        username:this.username,
                        roomid:this.roomid,
                        sendcards:this.sendcards,
                        option:'play'
                    }
                    var msg = JSON.stringify(data)
                    console.log(msg)
                    client.send(msg)
                    this.activity=false
                    this.clear()
                }
                else{
                    this.cardtips = '您的牌管不住上一个玩家'
                    this.clear()
                }

            }
        },
        clear(){
            this.sendcards = []
            $('.mid_li > div').attr('class','mid_card')
        },
        no(){
            this.cardtips = '不出'
            var client = this.ws
            var data = {
                username:this.username,
                roomid:this.roomid,
                precards:this.precards,
                preclientid:this.preclientid,
                option:'no'
            }
            var msg = JSON.stringify(data)
            console.log(msg)
            client.send(msg)
            this.activity=false
            this.clear()
        },
        ascOrder(x,y){
            if (x > y){
                return 1
            }
            else if (y > x){
                return -1
            }
            else{
                return 0
            }
        },
        change(id,val){
            let classname = document.getElementById(id).className
            if(classname == "mid_card_choose"){
                document.getElementById(id).className = "mid_card"
            }
            else {
                document.getElementById(id).className = "mid_card_choose"
            }
            let notexist= true
            for(let i =0;i<this.sendcards.length;i++){
                let cur_id = this.sendcards[i][0]
                if(cur_id == id){
                    this.sendcards.splice(i,1)
                    notexist = false
                    break
                }
            }
            if(notexist){
                this.sendcards.push([parseInt(id),parseInt(val)])
            }
            //console.log(this.sendcards)

        },
        connection(){
            if("WebSocket" in window){
                this.gameover=false
                this.ws = new WebSocket('ws://192.168.0.101:8001')
                var client = this.ws
                var context = this
                this.ws.onopen = function (e) {
                    console.log("连接服务器"+JSON.stringify(e))
                    var data = {
                        username:context.username,
                        roomid:context.roomid,
                        option:'conn'
                    }
                    var msg = JSON.stringify(data)
                    client.send(msg)
                }
                this.ws.onclose = function () {
                    console.log("服务器关闭")
                }
                this.ws.onerror = function () {
                    console.log("连接出错")
                }
                this.ws.onmessage = function (e) {
                    var resp = JSON.parse(e.data)
                    if(resp.resulttype == 0){
                        context.title = '等待其它玩家...'
                        if(context.clientid == ''){
                            context.clientid = resp.clientid
                        }
                    }
                    else if(resp.resulttype == 1){
                        context.title = '游戏已开始~~~'
                        if(context.clientid == ''){
                            context.clientid = resp.clientid
                        }
                        resp.cardlist.forEach(function (r,i) {
                            if(r.id == context.clientid){
                                context.landload=r.landload
                                context.owncardlist = r.cardlist
                                context.activity = r.activity
                                if(i == 0){
                                    //自己是0，上家是2，下家是1
                                    context.midplayer = resp.cardlist[0]
                                    context.leftplayer = resp.cardlist[2]
                                    context.rightplayer = resp.cardlist[1]
                                }
                                else if(i == 1){
                                    //自己是1，上家是0，下家是2
                                    context.midplayer = resp.cardlist[1]
                                    context.leftplayer = resp.cardlist[0]
                                    context.rightplayer = resp.cardlist[2]
                                }
                                else if(i == 2){
                                    //自己是2，上家是1，下家是0
                                    context.midplayer = resp.cardlist[2]
                                    context.leftplayer = resp.cardlist[1]
                                    context.rightplayer = resp.cardlist[0]
                                }
                            }
                        })
                        if(context.landload){
                            context.title = '地主'
                        }
                        else{
                            context.title = '农民'
                        }

                        if(resp.bottom){
                            context.bottomcardlist = resp.bottom
                        }
                        if(resp.precards){
                            context.precards = resp.precards
                        }
                        if(resp.preclientid){
                            context.preclientid = resp.preclientid
                        }

                    }
                    else if(resp.resulttype == 2){
                        //游戏结束
                        context.gameover = true
                        context.landloadwin = resp.landloadwin
                        client.close()
                        console.log('websocket 已关闭')
                        this.notbegin = true
                        this.sendcards = []
                        this.ws = null
                    }
                    //console.log(state.resp)
                }
            }

            else{
                console.log('不能使用WebSocket')
            }
            this.notbegin = false
        },
        disconnection(){
            var client = this.ws
            client.close()
            console.log('websocket 已关闭')
            this.notbegin = true
            this.sendcards = []
            this.ws = null

        }
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.logo{
    font-size:48px;
    color:red;
}
    .mid_ul{
        list-style: none;
        margin-left: 0px;
        height: 60px;
        border: solid 0px red;
        margin-top: 0;
        margin-bottom: 0;
    }
    .mid_li{
        display: inline-block;
        line-height: 30px;
        width:15px;
        height:30px;
        border: solid 0px red;
    }
    .mid_card{
        border:solid 1px black;
        width:15px;
        height:30px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 30px;
        background-color: white;
        color: black;
    }
    .mid_card_choose{
        border:solid 1px white;
        width:15px;
        height:30px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 30px;
        background-color: black;
        color: white;
    }
    .gameover{
        width:300px;
        height:150px;
        border:solid 0px red;
        margin: 0 auto;
        text-align: center
    }
    .card{
        border:solid 0px black;
        width:15px;
        height:30px;
        cursor: pointer;
        margin-left: 0px;
        display: inline-block;
        text-align: center;
        line-height: 30px;
    }
    #outer{
        border:solid 1px black;
        width:1000px;
        margin: 0 auto;
        text-align: center
    }
    .up{
        border:solid 0px red;
        width:400px;
        margin: 0 auto;
        text-align: center
    }
    .bottom{
        width:200px;
        margin: 0 auto;
        text-align: center
    }
    .in{
        border: solid 0px green;
        width:998px;
        height:150px;
    }
    .left{
        border: solid 0px blue;
        width:400px;
        height:200px;
        float: left;
    }
    .right{
        border:solid 0px cyan;
        width:400px;
        height:200px;
        margin-left: 190px;
        float: left;
    }
    .down{
        border: solid 0px green;
        width:998px;
        height:250px;
    }
    .mid_show{
        border: solid 0px orange;
        width:998px;
        height:100px;
    }
    .mid_cont{
        border:solid 0px orange;
        width:998px;
        height: 50px;
    }
    .middle{
        border: solid 0px orange;
        width:998px;
        height:100px;
    }
</style>
